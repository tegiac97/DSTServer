return {
  ["workshop-1250327920"]={ configuration_options={ active=true }, enabled=true },
  ["workshop-1474293089"]={ configuration_options={ auto_stack=true }, enabled=true },
  ["workshop-1484294726"]={ configuration_options={ musica=true, set_idioma="strings" }, enabled=true },
  ["workshop-1505270912"]={
    configuration_options={
      [""]=0,
      Beach_Biome=true,
      Deep_Jungle=true,
      Disable_Water=false,
      Jungle_Biome=true,
      Lavarena_Biome=true,
      Magma_Biome=true,
      Meadow_Biome=true,
      Plains_Hamlet=true,
      TheGorge_Biome=true,
      Tidalmarsh_Biome=true,
      Volcano_Biome=true,
      ["World Generation"]=5,
      boatlefthud=0,
      colourcube=true,
      fields=true,
      flood=true,
      hail=true,
      megarandomCompatibilityWater=false,
      painted_sands=true,
      set_idioma="strings",
      wind=true 
    },
    enabled=true 
  },
  ["workshop-1535658505"]={ configuration_options={ RECIPE=1 }, enabled=true },
  ["workshop-356930882"]={ configuration_options={ uses=10000000, uses2=10000000 }, enabled=true },
  ["workshop-362175979"]={ configuration_options={ ["Draw over FoW"]="disabled" }, enabled=true },
  ["workshop-375850593"]={ configuration_options={  }, enabled=true },
  ["workshop-378160973"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  },
  ["workshop-447092740"]={ configuration_options={  }, enabled=true },
  ["workshop-599498678"]={ configuration_options={  }, enabled=true },
  ["workshop-925172054"]={ configuration_options={ TAB=1, ganjabush_rate=1 }, enabled=true } 
}